/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;


public class Parametro {
    
    private String tipo;
    private String nome;

    public Parametro() {
        
    }
    
    public Parametro(String tipo, String nome) {
        setTipo(tipo);
        setNome(nome);
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    

    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        b.append(getTipo()).append(" ");
        b.append(getNome());
        return b.toString();
    }
    
}
