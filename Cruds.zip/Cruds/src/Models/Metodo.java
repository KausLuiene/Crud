/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;



public class Metodo {

    private String notacao;
    private String visibilidade;
    private String retorno;
    private String nome;
    private Collection<Parametro> parametros = new ArrayList<>();
    private String extra;
    private String txt;

    public Metodo() {

    }
    
    public Metodo(String visibilidade, String retorno, String nome) {
        setVisibilidade(visibilidade);
        setRetorno(retorno);
        setNome(nome);
    }

    /**
     * @return the notacao
     */
    public String getNotacao() {
        return notacao;
    }

    /**
     * @param notacao the notacao to set
     */
    public void setNotacao(String notacao) {
        this.notacao = notacao;
    }

    /**
     * @return the visibilidade
     */
    public String getVisibilidade() {
        return visibilidade;
    }

    /**
     * @param visibilidade the visibilidade to set
     */
    public void setVisibilidade(String visibilidade) {
        this.visibilidade = visibilidade;
    }

    /**
     * @return the retorno
     */
    public String getRetorno() {
        return retorno;
    }

    /**
     * @param retorno the retorno to set
     */
    public void setRetorno(String retorno) {
        this.retorno = retorno;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the parametros
     */
    public Collection<Parametro> getParametros() {
        return parametros;
    }

    /**
     * @param parametros the parametros to set
     */
    public void setParametros(Collection<Parametro> parametros) {
        this.parametros = parametros;
    }

    /**
     * @return the extra
     */
    public String getExtra() {
        return extra;
    }

    /**
     * @param extra the extra to set
     */
    public void setExtra(String extra) {
        this.extra = extra;
    }

    /**
     * @return the txt
     */
    public String getTxt() {
        return txt;
    }

    /**
     * @param txt the txt to set
     */
    public void setTxt(String txt) {
        this.txt = txt;
    }


    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        if (getNotacao() != null)
            b.append(getNotacao()).append("\n\t");
        if (getVisibilidade() != null)
            b.append(getVisibilidade()).append(" ");
        if (getRetorno() != null)
            b.append(getRetorno()).append(" ");
        b.append(getNome()).append("(");
        for (Iterator<Parametro> iterator = getParametros().iterator(); iterator.hasNext();) {
            Parametro p = iterator.next();
            b.append(p.toString());
            if (iterator.hasNext())
                b.append(", ");
        }
     
        b.append(")");
        if (getExtra() != null)
            b.append(" ").append(getExtra());
        b.append(" {\n").append(getTxt()).append("\n\t}");
        return b.toString();
    }

}
