/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author usuario
 */
public class Classe {
    
    private String pacote;
    private Collection<String> imports = new ArrayList<>();
    private Boolean importSuccess;
    private String nome;
    private String nomeExtra;
    private Collection<Atributo> atributos = new ArrayList<>();
    private Collection<Metodo> metodos = new ArrayList<>();

    public Classe() {
        importSuccess = false;
    }
    
    public Classe(String nome) {
        setNome(nome);
        importSuccess = false;
    }

    /**
     * @return the pacote
     */
    public String getPacote() {
        return pacote;
    }

    /**
     * @param pacote the pacote to set
     */
    public void setPacote(String pacote) {
        this.pacote = pacote;
    }

    /**
     * @return the imports
     */
    public Collection<String> getImports() {
        return imports;
    }

    /**
     * @param imports the imports to set
     */
    public void setImports(Collection<String> imports) {
        this.imports = imports;
    }

    /**
     * @return the importSuccess
     */
    public Boolean getImportSuccess() {
        return importSuccess;
    }

    /**
     * @param importSuccess the importSuccess to set
     */
    public void setImportSuccess(Boolean importSuccess) {
        this.importSuccess = importSuccess;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the nomeExtra
     */
    public String getNomeExtra() {
        return nomeExtra;
    }

    /**
     * @param nomeExtra the nomeExtra to set
     */
    public void setNomeExtra(String nomeExtra) {
        this.nomeExtra = nomeExtra;
    }

    /**
     * @return the atributos
     */
    public Collection<Atributo> getAtributos() {
        return atributos;
    }

    /**
     * @param atributos the atributos to set
     */
    public void setAtributos(Collection<Atributo> atributos) {
        this.atributos = atributos;
    }

    /**
     * @return the metodos
     */
    public Collection<Metodo> getMetodos() {
        return metodos;
    }

    /**
     * @param metodos the metodos to set
     */
    public void setMetodos(Collection<Metodo> metodos) {
        this.metodos = metodos;
    }


    @Override
    public String toString() {
        StringBuilder b = new StringBuilder();
        b.append("package ").append(getPacote()).append(";\n\n");
        for (String i : getImports())
            b.append("import ").append(i).append(";\n");
        b.append("\n");
        b.append("public class" + " ");
        if (getNomeExtra() != null)
            b.append(getNomeExtra()).append(" {\n");
        else
            b.append(getNome()).append(" {\n\n");
        for (Atributo a : getAtributos()) 
            b.append("\t").append(a.toString()).append(";\n");
        b.append("\n");
        for (Metodo m : getMetodos()) 
            b.append("\t").append(m.toString()).append("\n\n");
        b.append("}");
                
        return b.toString();
    }
    
}
