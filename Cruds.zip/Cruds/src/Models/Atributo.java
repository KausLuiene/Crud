/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author usuario
 */
public class Atributo {
    
    private String visibilidade;
    private String tipo;
    private String nome;

    public Atributo() {
        
    }
    
    public Atributo(String visibilidade, String tipo, String nome) {
        setVisibilidade(visibilidade);
        setTipo(tipo);
        setNome(nome);
    }

    /**
     * @return the visibilidade
     */
    public String getVisibilidade() {
        return visibilidade;
    }

    /**
     * @param visibilidade the visibilidade to set
     */
    public void setVisibilidade(String visibilidade) {
        this.visibilidade = visibilidade;
    }

    /**
     * @return the tipo
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * @param tipo the tipo to set
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }
    
    
    @Override 
    public String toString() {
        StringBuilder b = new StringBuilder();
        if (getVisibilidade() != null)
            b.append(getVisibilidade()).append(" ");
        b.append(getTipo()).append(" ");
        b.append(getNome());
        return b.toString();    
    }
    
}
