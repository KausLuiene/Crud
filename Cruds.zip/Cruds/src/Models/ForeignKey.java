/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;


public class ForeignKey {
    
    private String nome;
    private Tabela tabelaReferenciada;
    private String nomeTabelaReferenciada;
    private String colunaReferenciada;

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the tabelaReferenciada
     */
    public Tabela getTabelaReferenciada() {
        return tabelaReferenciada;
    }

    /**
     * @param tabelaReferenciada the tabelaReferenciada to set
     */
    public void setTabelaReferenciada(Tabela tabelaReferenciada) {
        this.tabelaReferenciada = tabelaReferenciada;
    }

    /**
     * @return the nomeTabelaReferenciada
     */
    public String getNomeTabelaReferenciada() {
        return nomeTabelaReferenciada;
    }

    /**
     * @param nomeTabelaReferenciada the nomeTabelaReferenciada to set
     */
    public void setNomeTabelaReferenciada(String nomeTabelaReferenciada) {
        this.nomeTabelaReferenciada = nomeTabelaReferenciada;
    }

    /**
     * @return the colunaReferenciada
     */
    public String getColunaReferenciada() {
        return colunaReferenciada;
    }

    /**
     * @param colunaReferenciada the colunaReferenciada to set
     */
    public void setColunaReferenciada(String colunaReferenciada) {
        this.colunaReferenciada = colunaReferenciada;
    }

    
}
